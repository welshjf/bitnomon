Changes
=======

0.1.2 (2015-02-01)
------------------

* Simplify subcommand invocation (hopefully more correct and less fragile)

0.1.1 (2015-01-26)
------------------

* Use README/CHANGES in long_description for PyPI
* Fix syntax in README examples
* Support older setuptools (CentOS 6)

0.1.0 (2015-01-26)
------------------

* Initial release
